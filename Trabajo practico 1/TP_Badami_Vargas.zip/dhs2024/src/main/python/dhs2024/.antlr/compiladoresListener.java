// Generated from /home/ben/Documentos/DHS/MavenDHS/dhs2024/src/main/python/dhs2024/compiladores.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link compiladoresParser}.
 */
public interface compiladoresListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#programa}.
	 * @param ctx the parse tree
	 */
	void enterPrograma(compiladoresParser.ProgramaContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#programa}.
	 * @param ctx the parse tree
	 */
	void exitPrograma(compiladoresParser.ProgramaContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#instrucciones}.
	 * @param ctx the parse tree
	 */
	void enterInstrucciones(compiladoresParser.InstruccionesContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#instrucciones}.
	 * @param ctx the parse tree
	 */
	void exitInstrucciones(compiladoresParser.InstruccionesContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#instruccion}.
	 * @param ctx the parse tree
	 */
	void enterInstruccion(compiladoresParser.InstruccionContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#instruccion}.
	 * @param ctx the parse tree
	 */
	void exitInstruccion(compiladoresParser.InstruccionContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#declaracion}.
	 * @param ctx the parse tree
	 */
	void enterDeclaracion(compiladoresParser.DeclaracionContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#declaracion}.
	 * @param ctx the parse tree
	 */
	void exitDeclaracion(compiladoresParser.DeclaracionContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#tipo}.
	 * @param ctx the parse tree
	 */
	void enterTipo(compiladoresParser.TipoContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#tipo}.
	 * @param ctx the parse tree
	 */
	void exitTipo(compiladoresParser.TipoContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#asignacion}.
	 * @param ctx the parse tree
	 */
	void enterAsignacion(compiladoresParser.AsignacionContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#asignacion}.
	 * @param ctx the parse tree
	 */
	void exitAsignacion(compiladoresParser.AsignacionContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#opal}.
	 * @param ctx the parse tree
	 */
	void enterOpal(compiladoresParser.OpalContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#opal}.
	 * @param ctx the parse tree
	 */
	void exitOpal(compiladoresParser.OpalContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterExp(compiladoresParser.ExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitExp(compiladoresParser.ExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#lor}.
	 * @param ctx the parse tree
	 */
	void enterLor(compiladoresParser.LorContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#lor}.
	 * @param ctx the parse tree
	 */
	void exitLor(compiladoresParser.LorContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#a}.
	 * @param ctx the parse tree
	 */
	void enterA(compiladoresParser.AContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#a}.
	 * @param ctx the parse tree
	 */
	void exitA(compiladoresParser.AContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#land}.
	 * @param ctx the parse tree
	 */
	void enterLand(compiladoresParser.LandContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#land}.
	 * @param ctx the parse tree
	 */
	void exitLand(compiladoresParser.LandContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#l}.
	 * @param ctx the parse tree
	 */
	void enterL(compiladoresParser.LContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#l}.
	 * @param ctx the parse tree
	 */
	void exitL(compiladoresParser.LContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#inot}.
	 * @param ctx the parse tree
	 */
	void enterInot(compiladoresParser.InotContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#inot}.
	 * @param ctx the parse tree
	 */
	void exitInot(compiladoresParser.InotContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#n}.
	 * @param ctx the parse tree
	 */
	void enterN(compiladoresParser.NContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#n}.
	 * @param ctx the parse tree
	 */
	void exitN(compiladoresParser.NContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#comp}.
	 * @param ctx the parse tree
	 */
	void enterComp(compiladoresParser.CompContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#comp}.
	 * @param ctx the parse tree
	 */
	void exitComp(compiladoresParser.CompContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#c}.
	 * @param ctx the parse tree
	 */
	void enterC(compiladoresParser.CContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#c}.
	 * @param ctx the parse tree
	 */
	void exitC(compiladoresParser.CContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#op}.
	 * @param ctx the parse tree
	 */
	void enterOp(compiladoresParser.OpContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#op}.
	 * @param ctx the parse tree
	 */
	void exitOp(compiladoresParser.OpContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#e}.
	 * @param ctx the parse tree
	 */
	void enterE(compiladoresParser.EContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#e}.
	 * @param ctx the parse tree
	 */
	void exitE(compiladoresParser.EContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#term}.
	 * @param ctx the parse tree
	 */
	void enterTerm(compiladoresParser.TermContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#term}.
	 * @param ctx the parse tree
	 */
	void exitTerm(compiladoresParser.TermContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#t}.
	 * @param ctx the parse tree
	 */
	void enterT(compiladoresParser.TContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#t}.
	 * @param ctx the parse tree
	 */
	void exitT(compiladoresParser.TContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#factor}.
	 * @param ctx the parse tree
	 */
	void enterFactor(compiladoresParser.FactorContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#factor}.
	 * @param ctx the parse tree
	 */
	void exitFactor(compiladoresParser.FactorContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#suf}.
	 * @param ctx the parse tree
	 */
	void enterSuf(compiladoresParser.SufContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#suf}.
	 * @param ctx the parse tree
	 */
	void exitSuf(compiladoresParser.SufContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#pref}.
	 * @param ctx the parse tree
	 */
	void enterPref(compiladoresParser.PrefContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#pref}.
	 * @param ctx the parse tree
	 */
	void exitPref(compiladoresParser.PrefContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#iwhile}.
	 * @param ctx the parse tree
	 */
	void enterIwhile(compiladoresParser.IwhileContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#iwhile}.
	 * @param ctx the parse tree
	 */
	void exitIwhile(compiladoresParser.IwhileContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterCond(compiladoresParser.CondContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitCond(compiladoresParser.CondContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#bloque}.
	 * @param ctx the parse tree
	 */
	void enterBloque(compiladoresParser.BloqueContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#bloque}.
	 * @param ctx the parse tree
	 */
	void exitBloque(compiladoresParser.BloqueContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#ifor}.
	 * @param ctx the parse tree
	 */
	void enterIfor(compiladoresParser.IforContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#ifor}.
	 * @param ctx the parse tree
	 */
	void exitIfor(compiladoresParser.IforContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#init}.
	 * @param ctx the parse tree
	 */
	void enterInit(compiladoresParser.InitContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#init}.
	 * @param ctx the parse tree
	 */
	void exitInit(compiladoresParser.InitContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#condlist}.
	 * @param ctx the parse tree
	 */
	void enterCondlist(compiladoresParser.CondlistContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#condlist}.
	 * @param ctx the parse tree
	 */
	void exitCondlist(compiladoresParser.CondlistContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#iter}.
	 * @param ctx the parse tree
	 */
	void enterIter(compiladoresParser.IterContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#iter}.
	 * @param ctx the parse tree
	 */
	void exitIter(compiladoresParser.IterContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#iif}.
	 * @param ctx the parse tree
	 */
	void enterIif(compiladoresParser.IifContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#iif}.
	 * @param ctx the parse tree
	 */
	void exitIif(compiladoresParser.IifContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#ielse}.
	 * @param ctx the parse tree
	 */
	void enterIelse(compiladoresParser.IelseContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#ielse}.
	 * @param ctx the parse tree
	 */
	void exitIelse(compiladoresParser.IelseContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#ifuncion}.
	 * @param ctx the parse tree
	 */
	void enterIfuncion(compiladoresParser.IfuncionContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#ifuncion}.
	 * @param ctx the parse tree
	 */
	void exitIfuncion(compiladoresParser.IfuncionContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#param}.
	 * @param ctx the parse tree
	 */
	void enterParam(compiladoresParser.ParamContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#param}.
	 * @param ctx the parse tree
	 */
	void exitParam(compiladoresParser.ParamContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#ireturn}.
	 * @param ctx the parse tree
	 */
	void enterIreturn(compiladoresParser.IreturnContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#ireturn}.
	 * @param ctx the parse tree
	 */
	void exitIreturn(compiladoresParser.IreturnContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#illamada}.
	 * @param ctx the parse tree
	 */
	void enterIllamada(compiladoresParser.IllamadaContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#illamada}.
	 * @param ctx the parse tree
	 */
	void exitIllamada(compiladoresParser.IllamadaContext ctx);
	/**
	 * Enter a parse tree produced by {@link compiladoresParser#argumento}.
	 * @param ctx the parse tree
	 */
	void enterArgumento(compiladoresParser.ArgumentoContext ctx);
	/**
	 * Exit a parse tree produced by {@link compiladoresParser#argumento}.
	 * @param ctx the parse tree
	 */
	void exitArgumento(compiladoresParser.ArgumentoContext ctx);
}