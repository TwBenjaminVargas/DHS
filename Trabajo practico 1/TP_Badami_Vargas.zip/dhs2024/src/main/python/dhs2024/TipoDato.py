from enum import Enum
class TipoDato(Enum):
    VOID = 0
    INT = 1
    FLOAT = 2
    CHAR = 3