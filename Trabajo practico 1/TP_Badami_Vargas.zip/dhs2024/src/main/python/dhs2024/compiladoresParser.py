# Generated from /home/ben/Documentos/DHS/MavenDHS/dhs2024/src/main/python/dhs2024/compiladores.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,38,335,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,1,0,1,0,1,
        0,1,1,1,1,1,1,1,1,3,1,86,8,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,3,2,103,8,2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,
        1,3,3,3,113,8,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,3,4,123,8,4,1,5,
        1,5,1,6,1,6,1,6,1,6,1,6,1,6,3,6,133,8,6,1,7,1,7,1,8,1,8,1,9,1,9,
        1,9,1,10,1,10,1,10,1,10,1,10,3,10,147,8,10,1,11,1,11,1,11,1,12,1,
        12,1,12,1,12,1,12,3,12,157,8,12,1,13,1,13,1,13,1,14,1,14,1,14,1,
        14,1,14,1,14,1,14,1,14,1,14,3,14,171,8,14,1,15,1,15,1,15,1,16,1,
        16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,
        16,1,16,1,16,3,16,193,8,16,1,17,1,17,1,17,1,18,1,18,1,18,1,18,1,
        18,1,18,1,18,1,18,1,18,3,18,207,8,18,1,19,1,19,1,19,1,20,1,20,1,
        20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,3,20,225,8,
        20,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,3,21,237,8,
        21,1,22,1,22,1,22,1,23,1,23,1,23,1,24,1,24,1,24,1,24,1,24,1,24,1,
        25,1,25,3,25,253,8,25,1,26,1,26,1,26,1,26,1,27,1,27,1,27,1,27,1,
        27,1,27,1,27,1,27,1,27,1,27,1,28,1,28,3,28,271,8,28,1,29,1,29,3,
        29,275,8,29,1,30,1,30,1,30,1,30,3,30,281,8,30,1,31,1,31,1,31,1,31,
        1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,3,31,296,8,31,1,32,
        1,32,1,32,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,34,1,34,1,34,1,34,
        1,34,1,34,3,34,314,8,34,1,35,1,35,1,35,1,36,1,36,1,36,1,36,1,37,
        1,37,1,37,1,37,1,37,1,38,1,38,1,38,1,38,1,38,3,38,333,8,38,1,38,
        0,0,39,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,
        42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,0,2,1,0,33,
        36,1,0,14,15,338,0,78,1,0,0,0,2,85,1,0,0,0,4,102,1,0,0,0,6,112,1,
        0,0,0,8,122,1,0,0,0,10,124,1,0,0,0,12,132,1,0,0,0,14,134,1,0,0,0,
        16,136,1,0,0,0,18,138,1,0,0,0,20,146,1,0,0,0,22,148,1,0,0,0,24,156,
        1,0,0,0,26,158,1,0,0,0,28,170,1,0,0,0,30,172,1,0,0,0,32,192,1,0,
        0,0,34,194,1,0,0,0,36,206,1,0,0,0,38,208,1,0,0,0,40,224,1,0,0,0,
        42,236,1,0,0,0,44,238,1,0,0,0,46,241,1,0,0,0,48,244,1,0,0,0,50,252,
        1,0,0,0,52,254,1,0,0,0,54,258,1,0,0,0,56,270,1,0,0,0,58,274,1,0,
        0,0,60,280,1,0,0,0,62,295,1,0,0,0,64,297,1,0,0,0,66,300,1,0,0,0,
        68,313,1,0,0,0,70,315,1,0,0,0,72,318,1,0,0,0,74,322,1,0,0,0,76,332,
        1,0,0,0,78,79,3,2,1,0,79,80,5,0,0,1,80,1,1,0,0,0,81,82,3,4,2,0,82,
        83,3,2,1,0,83,86,1,0,0,0,84,86,1,0,0,0,85,81,1,0,0,0,85,84,1,0,0,
        0,86,3,1,0,0,0,87,88,3,6,3,0,88,89,5,5,0,0,89,103,1,0,0,0,90,103,
        3,48,24,0,91,103,3,52,26,0,92,103,3,54,27,0,93,103,3,62,31,0,94,
        95,3,12,6,0,95,96,5,5,0,0,96,103,1,0,0,0,97,103,3,66,33,0,98,103,
        3,72,36,0,99,100,3,74,37,0,100,101,5,5,0,0,101,103,1,0,0,0,102,87,
        1,0,0,0,102,90,1,0,0,0,102,91,1,0,0,0,102,92,1,0,0,0,102,93,1,0,
        0,0,102,94,1,0,0,0,102,97,1,0,0,0,102,98,1,0,0,0,102,99,1,0,0,0,
        103,5,1,0,0,0,104,105,3,10,5,0,105,106,5,38,0,0,106,107,3,8,4,0,
        107,113,1,0,0,0,108,109,3,10,5,0,109,110,3,12,6,0,110,111,3,8,4,
        0,111,113,1,0,0,0,112,104,1,0,0,0,112,108,1,0,0,0,113,7,1,0,0,0,
        114,115,5,6,0,0,115,116,5,38,0,0,116,123,3,8,4,0,117,118,5,6,0,0,
        118,119,3,12,6,0,119,120,3,8,4,0,120,123,1,0,0,0,121,123,1,0,0,0,
        122,114,1,0,0,0,122,117,1,0,0,0,122,121,1,0,0,0,123,9,1,0,0,0,124,
        125,7,0,0,0,125,11,1,0,0,0,126,127,5,38,0,0,127,128,5,20,0,0,128,
        133,3,14,7,0,129,130,5,38,0,0,130,131,5,20,0,0,131,133,3,74,37,0,
        132,126,1,0,0,0,132,129,1,0,0,0,133,13,1,0,0,0,134,135,3,16,8,0,
        135,15,1,0,0,0,136,137,3,18,9,0,137,17,1,0,0,0,138,139,3,22,11,0,
        139,140,3,20,10,0,140,19,1,0,0,0,141,142,5,17,0,0,142,143,3,18,9,
        0,143,144,3,20,10,0,144,147,1,0,0,0,145,147,1,0,0,0,146,141,1,0,
        0,0,146,145,1,0,0,0,147,21,1,0,0,0,148,149,3,26,13,0,149,150,3,24,
        12,0,150,23,1,0,0,0,151,152,5,16,0,0,152,153,3,22,11,0,153,154,3,
        24,12,0,154,157,1,0,0,0,155,157,1,0,0,0,156,151,1,0,0,0,156,155,
        1,0,0,0,157,25,1,0,0,0,158,159,3,30,15,0,159,160,3,28,14,0,160,27,
        1,0,0,0,161,162,5,19,0,0,162,163,3,26,13,0,163,164,3,28,14,0,164,
        171,1,0,0,0,165,166,5,18,0,0,166,167,3,26,13,0,167,168,3,28,14,0,
        168,171,1,0,0,0,169,171,1,0,0,0,170,161,1,0,0,0,170,165,1,0,0,0,
        170,169,1,0,0,0,171,29,1,0,0,0,172,173,3,34,17,0,173,174,3,32,16,
        0,174,31,1,0,0,0,175,176,5,22,0,0,176,177,3,30,15,0,177,178,3,32,
        16,0,178,193,1,0,0,0,179,180,5,21,0,0,180,181,3,30,15,0,181,182,
        3,32,16,0,182,193,1,0,0,0,183,184,5,24,0,0,184,185,3,30,15,0,185,
        186,3,32,16,0,186,193,1,0,0,0,187,188,5,23,0,0,188,189,3,30,15,0,
        189,190,3,32,16,0,190,193,1,0,0,0,191,193,1,0,0,0,192,175,1,0,0,
        0,192,179,1,0,0,0,192,183,1,0,0,0,192,187,1,0,0,0,192,191,1,0,0,
        0,193,33,1,0,0,0,194,195,3,38,19,0,195,196,3,36,18,0,196,35,1,0,
        0,0,197,198,5,9,0,0,198,199,3,34,17,0,199,200,3,36,18,0,200,207,
        1,0,0,0,201,202,5,10,0,0,202,203,3,34,17,0,203,204,3,36,18,0,204,
        207,1,0,0,0,205,207,1,0,0,0,206,197,1,0,0,0,206,201,1,0,0,0,206,
        205,1,0,0,0,207,37,1,0,0,0,208,209,3,42,21,0,209,210,3,40,20,0,210,
        39,1,0,0,0,211,212,5,11,0,0,212,213,3,42,21,0,213,214,3,40,20,0,
        214,225,1,0,0,0,215,216,5,12,0,0,216,217,3,42,21,0,217,218,3,40,
        20,0,218,225,1,0,0,0,219,220,5,13,0,0,220,221,3,42,21,0,221,222,
        3,40,20,0,222,225,1,0,0,0,223,225,1,0,0,0,224,211,1,0,0,0,224,215,
        1,0,0,0,224,219,1,0,0,0,224,223,1,0,0,0,225,41,1,0,0,0,226,237,5,
        25,0,0,227,237,5,38,0,0,228,237,5,26,0,0,229,237,5,27,0,0,230,231,
        5,1,0,0,231,232,3,16,8,0,232,233,5,2,0,0,233,237,1,0,0,0,234,237,
        3,44,22,0,235,237,3,46,23,0,236,226,1,0,0,0,236,227,1,0,0,0,236,
        228,1,0,0,0,236,229,1,0,0,0,236,230,1,0,0,0,236,234,1,0,0,0,236,
        235,1,0,0,0,237,43,1,0,0,0,238,239,5,38,0,0,239,240,7,1,0,0,240,
        45,1,0,0,0,241,242,7,1,0,0,242,243,5,38,0,0,243,47,1,0,0,0,244,245,
        5,28,0,0,245,246,5,1,0,0,246,247,3,50,25,0,247,248,5,2,0,0,248,249,
        3,4,2,0,249,49,1,0,0,0,250,253,3,14,7,0,251,253,3,42,21,0,252,250,
        1,0,0,0,252,251,1,0,0,0,253,51,1,0,0,0,254,255,5,3,0,0,255,256,3,
        2,1,0,256,257,5,4,0,0,257,53,1,0,0,0,258,259,5,29,0,0,259,260,5,
        1,0,0,260,261,3,56,28,0,261,262,5,5,0,0,262,263,3,58,29,0,263,264,
        5,5,0,0,264,265,3,60,30,0,265,266,5,2,0,0,266,267,3,4,2,0,267,55,
        1,0,0,0,268,271,3,12,6,0,269,271,1,0,0,0,270,268,1,0,0,0,270,269,
        1,0,0,0,271,57,1,0,0,0,272,275,3,50,25,0,273,275,1,0,0,0,274,272,
        1,0,0,0,274,273,1,0,0,0,275,59,1,0,0,0,276,281,1,0,0,0,277,281,3,
        12,6,0,278,281,3,44,22,0,279,281,3,46,23,0,280,276,1,0,0,0,280,277,
        1,0,0,0,280,278,1,0,0,0,280,279,1,0,0,0,281,61,1,0,0,0,282,283,5,
        30,0,0,283,284,5,1,0,0,284,285,3,50,25,0,285,286,5,2,0,0,286,287,
        3,4,2,0,287,296,1,0,0,0,288,289,5,30,0,0,289,290,5,1,0,0,290,291,
        3,50,25,0,291,292,5,2,0,0,292,293,3,4,2,0,293,294,3,64,32,0,294,
        296,1,0,0,0,295,282,1,0,0,0,295,288,1,0,0,0,296,63,1,0,0,0,297,298,
        5,31,0,0,298,299,3,4,2,0,299,65,1,0,0,0,300,301,3,10,5,0,301,302,
        5,38,0,0,302,303,5,1,0,0,303,304,3,68,34,0,304,305,5,2,0,0,305,306,
        3,4,2,0,306,67,1,0,0,0,307,308,3,70,35,0,308,309,5,6,0,0,309,310,
        3,68,34,0,310,314,1,0,0,0,311,314,3,70,35,0,312,314,1,0,0,0,313,
        307,1,0,0,0,313,311,1,0,0,0,313,312,1,0,0,0,314,69,1,0,0,0,315,316,
        3,10,5,0,316,317,5,38,0,0,317,71,1,0,0,0,318,319,5,32,0,0,319,320,
        3,14,7,0,320,321,5,5,0,0,321,73,1,0,0,0,322,323,5,38,0,0,323,324,
        5,1,0,0,324,325,3,76,38,0,325,326,5,2,0,0,326,75,1,0,0,0,327,328,
        5,38,0,0,328,329,5,6,0,0,329,333,3,76,38,0,330,333,5,38,0,0,331,
        333,1,0,0,0,332,327,1,0,0,0,332,330,1,0,0,0,332,331,1,0,0,0,333,
        77,1,0,0,0,19,85,102,112,122,132,146,156,170,192,206,224,236,252,
        270,274,280,295,313,332
    ]

class compiladoresParser ( Parser ):

    grammarFileName = "compiladores.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'('", "')'", "'{'", "'}'", "';'", "','", 
                     "'.'", "'''", "'+'", "'-'", "'*'", "'/'", "'%'", "'++'", 
                     "'--'", "'&&'", "'||'", "'=='", "'!='", "'='", "'<'", 
                     "'>'", "'<='", "'>='", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'while'", "'for'", "'if'", "'else'", "'return'", "'int'", 
                     "'float'", "'char'", "'void'" ]

    symbolicNames = [ "<INVALID>", "PA", "PC", "LLA", "LLC", "PYC", "C", 
                      "PTO", "COMILLA", "SUMA", "RESTA", "MULT", "DIV", 
                      "MOD", "INC", "DEC", "AND", "OR", "IGUAL", "NOT", 
                      "ASIG", "MENOR", "MAYOR", "MEI", "MAI", "NUMERO", 
                      "DECIMAL", "CARACTER", "WHILE", "FOR", "IF", "ELSE", 
                      "RETURN", "INT", "FLOAT", "CHAR", "VOID", "WS", "ID" ]

    RULE_programa = 0
    RULE_instrucciones = 1
    RULE_instruccion = 2
    RULE_declaracion = 3
    RULE_dec = 4
    RULE_tipo = 5
    RULE_asignacion = 6
    RULE_opal = 7
    RULE_exp = 8
    RULE_lor = 9
    RULE_a = 10
    RULE_land = 11
    RULE_l = 12
    RULE_inot = 13
    RULE_n = 14
    RULE_comp = 15
    RULE_c = 16
    RULE_op = 17
    RULE_e = 18
    RULE_term = 19
    RULE_t = 20
    RULE_factor = 21
    RULE_suf = 22
    RULE_pref = 23
    RULE_iwhile = 24
    RULE_cond = 25
    RULE_bloque = 26
    RULE_ifor = 27
    RULE_init = 28
    RULE_condlist = 29
    RULE_iter = 30
    RULE_iif = 31
    RULE_ielse = 32
    RULE_ifuncion = 33
    RULE_param = 34
    RULE_p = 35
    RULE_ireturn = 36
    RULE_illamada = 37
    RULE_argumento = 38

    ruleNames =  [ "programa", "instrucciones", "instruccion", "declaracion", 
                   "dec", "tipo", "asignacion", "opal", "exp", "lor", "a", 
                   "land", "l", "inot", "n", "comp", "c", "op", "e", "term", 
                   "t", "factor", "suf", "pref", "iwhile", "cond", "bloque", 
                   "ifor", "init", "condlist", "iter", "iif", "ielse", "ifuncion", 
                   "param", "p", "ireturn", "illamada", "argumento" ]

    EOF = Token.EOF
    PA=1
    PC=2
    LLA=3
    LLC=4
    PYC=5
    C=6
    PTO=7
    COMILLA=8
    SUMA=9
    RESTA=10
    MULT=11
    DIV=12
    MOD=13
    INC=14
    DEC=15
    AND=16
    OR=17
    IGUAL=18
    NOT=19
    ASIG=20
    MENOR=21
    MAYOR=22
    MEI=23
    MAI=24
    NUMERO=25
    DECIMAL=26
    CARACTER=27
    WHILE=28
    FOR=29
    IF=30
    ELSE=31
    RETURN=32
    INT=33
    FLOAT=34
    CHAR=35
    VOID=36
    WS=37
    ID=38

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def instrucciones(self):
            return self.getTypedRuleContext(compiladoresParser.InstruccionesContext,0)


        def EOF(self):
            return self.getToken(compiladoresParser.EOF, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_programa

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrograma" ):
                listener.enterPrograma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrograma" ):
                listener.exitPrograma(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrograma" ):
                return visitor.visitPrograma(self)
            else:
                return visitor.visitChildren(self)




    def programa(self):

        localctx = compiladoresParser.ProgramaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_programa)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 78
            self.instrucciones()
            self.state = 79
            self.match(compiladoresParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstruccionesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def instruccion(self):
            return self.getTypedRuleContext(compiladoresParser.InstruccionContext,0)


        def instrucciones(self):
            return self.getTypedRuleContext(compiladoresParser.InstruccionesContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_instrucciones

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstrucciones" ):
                listener.enterInstrucciones(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstrucciones" ):
                listener.exitInstrucciones(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstrucciones" ):
                return visitor.visitInstrucciones(self)
            else:
                return visitor.visitChildren(self)




    def instrucciones(self):

        localctx = compiladoresParser.InstruccionesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_instrucciones)
        try:
            self.state = 85
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [3, 28, 29, 30, 32, 33, 34, 35, 36, 38]:
                self.enterOuterAlt(localctx, 1)
                self.state = 81
                self.instruccion()
                self.state = 82
                self.instrucciones()
                pass
            elif token in [-1, 4]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstruccionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declaracion(self):
            return self.getTypedRuleContext(compiladoresParser.DeclaracionContext,0)


        def PYC(self):
            return self.getToken(compiladoresParser.PYC, 0)

        def iwhile(self):
            return self.getTypedRuleContext(compiladoresParser.IwhileContext,0)


        def bloque(self):
            return self.getTypedRuleContext(compiladoresParser.BloqueContext,0)


        def ifor(self):
            return self.getTypedRuleContext(compiladoresParser.IforContext,0)


        def iif(self):
            return self.getTypedRuleContext(compiladoresParser.IifContext,0)


        def asignacion(self):
            return self.getTypedRuleContext(compiladoresParser.AsignacionContext,0)


        def ifuncion(self):
            return self.getTypedRuleContext(compiladoresParser.IfuncionContext,0)


        def ireturn(self):
            return self.getTypedRuleContext(compiladoresParser.IreturnContext,0)


        def illamada(self):
            return self.getTypedRuleContext(compiladoresParser.IllamadaContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_instruccion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstruccion" ):
                listener.enterInstruccion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstruccion" ):
                listener.exitInstruccion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstruccion" ):
                return visitor.visitInstruccion(self)
            else:
                return visitor.visitChildren(self)




    def instruccion(self):

        localctx = compiladoresParser.InstruccionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_instruccion)
        try:
            self.state = 102
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 87
                self.declaracion()
                self.state = 88
                self.match(compiladoresParser.PYC)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 90
                self.iwhile()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 91
                self.bloque()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 92
                self.ifor()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 93
                self.iif()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 94
                self.asignacion()
                self.state = 95
                self.match(compiladoresParser.PYC)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 97
                self.ifuncion()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 98
                self.ireturn()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 99
                self.illamada()
                self.state = 100
                self.match(compiladoresParser.PYC)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclaracionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(compiladoresParser.TipoContext,0)


        def ID(self):
            return self.getToken(compiladoresParser.ID, 0)

        def dec(self):
            return self.getTypedRuleContext(compiladoresParser.DecContext,0)


        def asignacion(self):
            return self.getTypedRuleContext(compiladoresParser.AsignacionContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_declaracion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaracion" ):
                listener.enterDeclaracion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaracion" ):
                listener.exitDeclaracion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclaracion" ):
                return visitor.visitDeclaracion(self)
            else:
                return visitor.visitChildren(self)




    def declaracion(self):

        localctx = compiladoresParser.DeclaracionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_declaracion)
        try:
            self.state = 112
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 104
                self.tipo()
                self.state = 105
                self.match(compiladoresParser.ID)
                self.state = 106
                self.dec()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 108
                self.tipo()
                self.state = 109
                self.asignacion()
                self.state = 110
                self.dec()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DecContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def C(self):
            return self.getToken(compiladoresParser.C, 0)

        def ID(self):
            return self.getToken(compiladoresParser.ID, 0)

        def dec(self):
            return self.getTypedRuleContext(compiladoresParser.DecContext,0)


        def asignacion(self):
            return self.getTypedRuleContext(compiladoresParser.AsignacionContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_dec

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDec" ):
                listener.enterDec(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDec" ):
                listener.exitDec(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDec" ):
                return visitor.visitDec(self)
            else:
                return visitor.visitChildren(self)




    def dec(self):

        localctx = compiladoresParser.DecContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_dec)
        try:
            self.state = 122
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 114
                self.match(compiladoresParser.C)
                self.state = 115
                self.match(compiladoresParser.ID)
                self.state = 116
                self.dec()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 117
                self.match(compiladoresParser.C)
                self.state = 118
                self.asignacion()
                self.state = 119
                self.dec()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TipoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(compiladoresParser.INT, 0)

        def VOID(self):
            return self.getToken(compiladoresParser.VOID, 0)

        def FLOAT(self):
            return self.getToken(compiladoresParser.FLOAT, 0)

        def CHAR(self):
            return self.getToken(compiladoresParser.CHAR, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_tipo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTipo" ):
                listener.enterTipo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTipo" ):
                listener.exitTipo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTipo" ):
                return visitor.visitTipo(self)
            else:
                return visitor.visitChildren(self)




    def tipo(self):

        localctx = compiladoresParser.TipoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_tipo)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 124
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 128849018880) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AsignacionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(compiladoresParser.ID, 0)

        def ASIG(self):
            return self.getToken(compiladoresParser.ASIG, 0)

        def opal(self):
            return self.getTypedRuleContext(compiladoresParser.OpalContext,0)


        def illamada(self):
            return self.getTypedRuleContext(compiladoresParser.IllamadaContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_asignacion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsignacion" ):
                listener.enterAsignacion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsignacion" ):
                listener.exitAsignacion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAsignacion" ):
                return visitor.visitAsignacion(self)
            else:
                return visitor.visitChildren(self)




    def asignacion(self):

        localctx = compiladoresParser.AsignacionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_asignacion)
        try:
            self.state = 132
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 126
                self.match(compiladoresParser.ID)
                self.state = 127
                self.match(compiladoresParser.ASIG)
                self.state = 128
                self.opal()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 129
                self.match(compiladoresParser.ID)
                self.state = 130
                self.match(compiladoresParser.ASIG)
                self.state = 131
                self.illamada()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OpalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp(self):
            return self.getTypedRuleContext(compiladoresParser.ExpContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_opal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOpal" ):
                listener.enterOpal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOpal" ):
                listener.exitOpal(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOpal" ):
                return visitor.visitOpal(self)
            else:
                return visitor.visitChildren(self)




    def opal(self):

        localctx = compiladoresParser.OpalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_opal)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 134
            self.exp()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def lor(self):
            return self.getTypedRuleContext(compiladoresParser.LorContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_exp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExp" ):
                listener.enterExp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExp" ):
                listener.exitExp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExp" ):
                return visitor.visitExp(self)
            else:
                return visitor.visitChildren(self)




    def exp(self):

        localctx = compiladoresParser.ExpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_exp)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 136
            self.lor()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def land(self):
            return self.getTypedRuleContext(compiladoresParser.LandContext,0)


        def a(self):
            return self.getTypedRuleContext(compiladoresParser.AContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_lor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLor" ):
                listener.enterLor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLor" ):
                listener.exitLor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLor" ):
                return visitor.visitLor(self)
            else:
                return visitor.visitChildren(self)




    def lor(self):

        localctx = compiladoresParser.LorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_lor)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 138
            self.land()
            self.state = 139
            self.a()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OR(self):
            return self.getToken(compiladoresParser.OR, 0)

        def lor(self):
            return self.getTypedRuleContext(compiladoresParser.LorContext,0)


        def a(self):
            return self.getTypedRuleContext(compiladoresParser.AContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_a

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterA" ):
                listener.enterA(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitA" ):
                listener.exitA(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitA" ):
                return visitor.visitA(self)
            else:
                return visitor.visitChildren(self)




    def a(self):

        localctx = compiladoresParser.AContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_a)
        try:
            self.state = 146
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 141
                self.match(compiladoresParser.OR)
                self.state = 142
                self.lor()
                self.state = 143
                self.a()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LandContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def inot(self):
            return self.getTypedRuleContext(compiladoresParser.InotContext,0)


        def l(self):
            return self.getTypedRuleContext(compiladoresParser.LContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_land

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLand" ):
                listener.enterLand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLand" ):
                listener.exitLand(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLand" ):
                return visitor.visitLand(self)
            else:
                return visitor.visitChildren(self)




    def land(self):

        localctx = compiladoresParser.LandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_land)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 148
            self.inot()
            self.state = 149
            self.l()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def AND(self):
            return self.getToken(compiladoresParser.AND, 0)

        def land(self):
            return self.getTypedRuleContext(compiladoresParser.LandContext,0)


        def l(self):
            return self.getTypedRuleContext(compiladoresParser.LContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_l

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterL" ):
                listener.enterL(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitL" ):
                listener.exitL(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitL" ):
                return visitor.visitL(self)
            else:
                return visitor.visitChildren(self)




    def l(self):

        localctx = compiladoresParser.LContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_l)
        try:
            self.state = 156
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 151
                self.match(compiladoresParser.AND)
                self.state = 152
                self.land()
                self.state = 153
                self.l()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InotContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def comp(self):
            return self.getTypedRuleContext(compiladoresParser.CompContext,0)


        def n(self):
            return self.getTypedRuleContext(compiladoresParser.NContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_inot

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInot" ):
                listener.enterInot(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInot" ):
                listener.exitInot(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInot" ):
                return visitor.visitInot(self)
            else:
                return visitor.visitChildren(self)




    def inot(self):

        localctx = compiladoresParser.InotContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_inot)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.comp()
            self.state = 159
            self.n()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NOT(self):
            return self.getToken(compiladoresParser.NOT, 0)

        def inot(self):
            return self.getTypedRuleContext(compiladoresParser.InotContext,0)


        def n(self):
            return self.getTypedRuleContext(compiladoresParser.NContext,0)


        def IGUAL(self):
            return self.getToken(compiladoresParser.IGUAL, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_n

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterN" ):
                listener.enterN(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitN" ):
                listener.exitN(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitN" ):
                return visitor.visitN(self)
            else:
                return visitor.visitChildren(self)




    def n(self):

        localctx = compiladoresParser.NContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_n)
        try:
            self.state = 170
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 161
                self.match(compiladoresParser.NOT)
                self.state = 162
                self.inot()
                self.state = 163
                self.n()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 165
                self.match(compiladoresParser.IGUAL)
                self.state = 166
                self.inot()
                self.state = 167
                self.n()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CompContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def op(self):
            return self.getTypedRuleContext(compiladoresParser.OpContext,0)


        def c(self):
            return self.getTypedRuleContext(compiladoresParser.CContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_comp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComp" ):
                listener.enterComp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComp" ):
                listener.exitComp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComp" ):
                return visitor.visitComp(self)
            else:
                return visitor.visitChildren(self)




    def comp(self):

        localctx = compiladoresParser.CompContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_comp)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 172
            self.op()
            self.state = 173
            self.c()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MAYOR(self):
            return self.getToken(compiladoresParser.MAYOR, 0)

        def comp(self):
            return self.getTypedRuleContext(compiladoresParser.CompContext,0)


        def c(self):
            return self.getTypedRuleContext(compiladoresParser.CContext,0)


        def MENOR(self):
            return self.getToken(compiladoresParser.MENOR, 0)

        def MAI(self):
            return self.getToken(compiladoresParser.MAI, 0)

        def MEI(self):
            return self.getToken(compiladoresParser.MEI, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_c

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterC" ):
                listener.enterC(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitC" ):
                listener.exitC(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitC" ):
                return visitor.visitC(self)
            else:
                return visitor.visitChildren(self)




    def c(self):

        localctx = compiladoresParser.CContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_c)
        try:
            self.state = 192
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 175
                self.match(compiladoresParser.MAYOR)
                self.state = 176
                self.comp()
                self.state = 177
                self.c()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 179
                self.match(compiladoresParser.MENOR)
                self.state = 180
                self.comp()
                self.state = 181
                self.c()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 183
                self.match(compiladoresParser.MAI)
                self.state = 184
                self.comp()
                self.state = 185
                self.c()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 187
                self.match(compiladoresParser.MEI)
                self.state = 188
                self.comp()
                self.state = 189
                self.c()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def term(self):
            return self.getTypedRuleContext(compiladoresParser.TermContext,0)


        def e(self):
            return self.getTypedRuleContext(compiladoresParser.EContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_op

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOp" ):
                listener.enterOp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOp" ):
                listener.exitOp(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOp" ):
                return visitor.visitOp(self)
            else:
                return visitor.visitChildren(self)




    def op(self):

        localctx = compiladoresParser.OpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_op)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 194
            self.term()
            self.state = 195
            self.e()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SUMA(self):
            return self.getToken(compiladoresParser.SUMA, 0)

        def op(self):
            return self.getTypedRuleContext(compiladoresParser.OpContext,0)


        def e(self):
            return self.getTypedRuleContext(compiladoresParser.EContext,0)


        def RESTA(self):
            return self.getToken(compiladoresParser.RESTA, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_e

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterE" ):
                listener.enterE(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitE" ):
                listener.exitE(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitE" ):
                return visitor.visitE(self)
            else:
                return visitor.visitChildren(self)




    def e(self):

        localctx = compiladoresParser.EContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_e)
        try:
            self.state = 206
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 197
                self.match(compiladoresParser.SUMA)
                self.state = 198
                self.op()
                self.state = 199
                self.e()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 201
                self.match(compiladoresParser.RESTA)
                self.state = 202
                self.op()
                self.state = 203
                self.e()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def factor(self):
            return self.getTypedRuleContext(compiladoresParser.FactorContext,0)


        def t(self):
            return self.getTypedRuleContext(compiladoresParser.TContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTerm" ):
                listener.enterTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTerm" ):
                listener.exitTerm(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTerm" ):
                return visitor.visitTerm(self)
            else:
                return visitor.visitChildren(self)




    def term(self):

        localctx = compiladoresParser.TermContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_term)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 208
            self.factor()
            self.state = 209
            self.t()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MULT(self):
            return self.getToken(compiladoresParser.MULT, 0)

        def factor(self):
            return self.getTypedRuleContext(compiladoresParser.FactorContext,0)


        def t(self):
            return self.getTypedRuleContext(compiladoresParser.TContext,0)


        def DIV(self):
            return self.getToken(compiladoresParser.DIV, 0)

        def MOD(self):
            return self.getToken(compiladoresParser.MOD, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_t

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterT" ):
                listener.enterT(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitT" ):
                listener.exitT(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitT" ):
                return visitor.visitT(self)
            else:
                return visitor.visitChildren(self)




    def t(self):

        localctx = compiladoresParser.TContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_t)
        try:
            self.state = 224
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [11]:
                self.enterOuterAlt(localctx, 1)
                self.state = 211
                self.match(compiladoresParser.MULT)
                self.state = 212
                self.factor()
                self.state = 213
                self.t()
                pass
            elif token in [12]:
                self.enterOuterAlt(localctx, 2)
                self.state = 215
                self.match(compiladoresParser.DIV)
                self.state = 216
                self.factor()
                self.state = 217
                self.t()
                pass
            elif token in [13]:
                self.enterOuterAlt(localctx, 3)
                self.state = 219
                self.match(compiladoresParser.MOD)
                self.state = 220
                self.factor()
                self.state = 221
                self.t()
                pass
            elif token in [2, 5, 6, 9, 10, 16, 17, 18, 19, 21, 22, 23, 24]:
                self.enterOuterAlt(localctx, 4)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMERO(self):
            return self.getToken(compiladoresParser.NUMERO, 0)

        def ID(self):
            return self.getToken(compiladoresParser.ID, 0)

        def DECIMAL(self):
            return self.getToken(compiladoresParser.DECIMAL, 0)

        def CARACTER(self):
            return self.getToken(compiladoresParser.CARACTER, 0)

        def PA(self):
            return self.getToken(compiladoresParser.PA, 0)

        def exp(self):
            return self.getTypedRuleContext(compiladoresParser.ExpContext,0)


        def PC(self):
            return self.getToken(compiladoresParser.PC, 0)

        def suf(self):
            return self.getTypedRuleContext(compiladoresParser.SufContext,0)


        def pref(self):
            return self.getTypedRuleContext(compiladoresParser.PrefContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor" ):
                listener.enterFactor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor" ):
                listener.exitFactor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor" ):
                return visitor.visitFactor(self)
            else:
                return visitor.visitChildren(self)




    def factor(self):

        localctx = compiladoresParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_factor)
        try:
            self.state = 236
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 226
                self.match(compiladoresParser.NUMERO)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 227
                self.match(compiladoresParser.ID)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 228
                self.match(compiladoresParser.DECIMAL)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 229
                self.match(compiladoresParser.CARACTER)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 230
                self.match(compiladoresParser.PA)
                self.state = 231
                self.exp()
                self.state = 232
                self.match(compiladoresParser.PC)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 234
                self.suf()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 235
                self.pref()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SufContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(compiladoresParser.ID, 0)

        def INC(self):
            return self.getToken(compiladoresParser.INC, 0)

        def DEC(self):
            return self.getToken(compiladoresParser.DEC, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_suf

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSuf" ):
                listener.enterSuf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSuf" ):
                listener.exitSuf(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSuf" ):
                return visitor.visitSuf(self)
            else:
                return visitor.visitChildren(self)




    def suf(self):

        localctx = compiladoresParser.SufContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_suf)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 238
            self.match(compiladoresParser.ID)
            self.state = 239
            _la = self._input.LA(1)
            if not(_la==14 or _la==15):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(compiladoresParser.ID, 0)

        def INC(self):
            return self.getToken(compiladoresParser.INC, 0)

        def DEC(self):
            return self.getToken(compiladoresParser.DEC, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_pref

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPref" ):
                listener.enterPref(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPref" ):
                listener.exitPref(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPref" ):
                return visitor.visitPref(self)
            else:
                return visitor.visitChildren(self)




    def pref(self):

        localctx = compiladoresParser.PrefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_pref)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 241
            _la = self._input.LA(1)
            if not(_la==14 or _la==15):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 242
            self.match(compiladoresParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IwhileContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(compiladoresParser.WHILE, 0)

        def PA(self):
            return self.getToken(compiladoresParser.PA, 0)

        def cond(self):
            return self.getTypedRuleContext(compiladoresParser.CondContext,0)


        def PC(self):
            return self.getToken(compiladoresParser.PC, 0)

        def instruccion(self):
            return self.getTypedRuleContext(compiladoresParser.InstruccionContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_iwhile

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIwhile" ):
                listener.enterIwhile(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIwhile" ):
                listener.exitIwhile(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIwhile" ):
                return visitor.visitIwhile(self)
            else:
                return visitor.visitChildren(self)




    def iwhile(self):

        localctx = compiladoresParser.IwhileContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_iwhile)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 244
            self.match(compiladoresParser.WHILE)
            self.state = 245
            self.match(compiladoresParser.PA)
            self.state = 246
            self.cond()
            self.state = 247
            self.match(compiladoresParser.PC)
            self.state = 248
            self.instruccion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CondContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def opal(self):
            return self.getTypedRuleContext(compiladoresParser.OpalContext,0)


        def factor(self):
            return self.getTypedRuleContext(compiladoresParser.FactorContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_cond

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCond" ):
                listener.enterCond(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCond" ):
                listener.exitCond(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCond" ):
                return visitor.visitCond(self)
            else:
                return visitor.visitChildren(self)




    def cond(self):

        localctx = compiladoresParser.CondContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_cond)
        try:
            self.state = 252
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,12,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 250
                self.opal()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 251
                self.factor()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BloqueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LLA(self):
            return self.getToken(compiladoresParser.LLA, 0)

        def instrucciones(self):
            return self.getTypedRuleContext(compiladoresParser.InstruccionesContext,0)


        def LLC(self):
            return self.getToken(compiladoresParser.LLC, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_bloque

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBloque" ):
                listener.enterBloque(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBloque" ):
                listener.exitBloque(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBloque" ):
                return visitor.visitBloque(self)
            else:
                return visitor.visitChildren(self)




    def bloque(self):

        localctx = compiladoresParser.BloqueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_bloque)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 254
            self.match(compiladoresParser.LLA)
            self.state = 255
            self.instrucciones()
            self.state = 256
            self.match(compiladoresParser.LLC)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IforContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(compiladoresParser.FOR, 0)

        def PA(self):
            return self.getToken(compiladoresParser.PA, 0)

        def init(self):
            return self.getTypedRuleContext(compiladoresParser.InitContext,0)


        def PYC(self, i:int=None):
            if i is None:
                return self.getTokens(compiladoresParser.PYC)
            else:
                return self.getToken(compiladoresParser.PYC, i)

        def condlist(self):
            return self.getTypedRuleContext(compiladoresParser.CondlistContext,0)


        def iter_(self):
            return self.getTypedRuleContext(compiladoresParser.IterContext,0)


        def PC(self):
            return self.getToken(compiladoresParser.PC, 0)

        def instruccion(self):
            return self.getTypedRuleContext(compiladoresParser.InstruccionContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_ifor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfor" ):
                listener.enterIfor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfor" ):
                listener.exitIfor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfor" ):
                return visitor.visitIfor(self)
            else:
                return visitor.visitChildren(self)




    def ifor(self):

        localctx = compiladoresParser.IforContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_ifor)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 258
            self.match(compiladoresParser.FOR)
            self.state = 259
            self.match(compiladoresParser.PA)
            self.state = 260
            self.init()
            self.state = 261
            self.match(compiladoresParser.PYC)
            self.state = 262
            self.condlist()
            self.state = 263
            self.match(compiladoresParser.PYC)
            self.state = 264
            self.iter_()
            self.state = 265
            self.match(compiladoresParser.PC)
            self.state = 266
            self.instruccion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InitContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def asignacion(self):
            return self.getTypedRuleContext(compiladoresParser.AsignacionContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_init

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInit" ):
                listener.enterInit(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInit" ):
                listener.exitInit(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInit" ):
                return visitor.visitInit(self)
            else:
                return visitor.visitChildren(self)




    def init(self):

        localctx = compiladoresParser.InitContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_init)
        try:
            self.state = 270
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [38]:
                self.enterOuterAlt(localctx, 1)
                self.state = 268
                self.asignacion()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CondlistContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def cond(self):
            return self.getTypedRuleContext(compiladoresParser.CondContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_condlist

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondlist" ):
                listener.enterCondlist(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondlist" ):
                listener.exitCondlist(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCondlist" ):
                return visitor.visitCondlist(self)
            else:
                return visitor.visitChildren(self)




    def condlist(self):

        localctx = compiladoresParser.CondlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_condlist)
        try:
            self.state = 274
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 14, 15, 25, 26, 27, 38]:
                self.enterOuterAlt(localctx, 1)
                self.state = 272
                self.cond()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IterContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def asignacion(self):
            return self.getTypedRuleContext(compiladoresParser.AsignacionContext,0)


        def suf(self):
            return self.getTypedRuleContext(compiladoresParser.SufContext,0)


        def pref(self):
            return self.getTypedRuleContext(compiladoresParser.PrefContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_iter

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIter" ):
                listener.enterIter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIter" ):
                listener.exitIter(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIter" ):
                return visitor.visitIter(self)
            else:
                return visitor.visitChildren(self)




    def iter_(self):

        localctx = compiladoresParser.IterContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_iter)
        try:
            self.state = 280
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)

                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 277
                self.asignacion()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 278
                self.suf()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 279
                self.pref()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IifContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(compiladoresParser.IF, 0)

        def PA(self):
            return self.getToken(compiladoresParser.PA, 0)

        def cond(self):
            return self.getTypedRuleContext(compiladoresParser.CondContext,0)


        def PC(self):
            return self.getToken(compiladoresParser.PC, 0)

        def instruccion(self):
            return self.getTypedRuleContext(compiladoresParser.InstruccionContext,0)


        def ielse(self):
            return self.getTypedRuleContext(compiladoresParser.IelseContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_iif

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIif" ):
                listener.enterIif(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIif" ):
                listener.exitIif(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIif" ):
                return visitor.visitIif(self)
            else:
                return visitor.visitChildren(self)




    def iif(self):

        localctx = compiladoresParser.IifContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_iif)
        try:
            self.state = 295
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 282
                self.match(compiladoresParser.IF)
                self.state = 283
                self.match(compiladoresParser.PA)
                self.state = 284
                self.cond()
                self.state = 285
                self.match(compiladoresParser.PC)
                self.state = 286
                self.instruccion()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 288
                self.match(compiladoresParser.IF)
                self.state = 289
                self.match(compiladoresParser.PA)
                self.state = 290
                self.cond()
                self.state = 291
                self.match(compiladoresParser.PC)
                self.state = 292
                self.instruccion()
                self.state = 293
                self.ielse()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IelseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ELSE(self):
            return self.getToken(compiladoresParser.ELSE, 0)

        def instruccion(self):
            return self.getTypedRuleContext(compiladoresParser.InstruccionContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_ielse

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIelse" ):
                listener.enterIelse(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIelse" ):
                listener.exitIelse(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIelse" ):
                return visitor.visitIelse(self)
            else:
                return visitor.visitChildren(self)




    def ielse(self):

        localctx = compiladoresParser.IelseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_ielse)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 297
            self.match(compiladoresParser.ELSE)
            self.state = 298
            self.instruccion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfuncionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(compiladoresParser.TipoContext,0)


        def ID(self):
            return self.getToken(compiladoresParser.ID, 0)

        def PA(self):
            return self.getToken(compiladoresParser.PA, 0)

        def param(self):
            return self.getTypedRuleContext(compiladoresParser.ParamContext,0)


        def PC(self):
            return self.getToken(compiladoresParser.PC, 0)

        def instruccion(self):
            return self.getTypedRuleContext(compiladoresParser.InstruccionContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_ifuncion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfuncion" ):
                listener.enterIfuncion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfuncion" ):
                listener.exitIfuncion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfuncion" ):
                return visitor.visitIfuncion(self)
            else:
                return visitor.visitChildren(self)




    def ifuncion(self):

        localctx = compiladoresParser.IfuncionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_ifuncion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 300
            self.tipo()
            self.state = 301
            self.match(compiladoresParser.ID)
            self.state = 302
            self.match(compiladoresParser.PA)
            self.state = 303
            self.param()
            self.state = 304
            self.match(compiladoresParser.PC)
            self.state = 305
            self.instruccion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def p(self):
            return self.getTypedRuleContext(compiladoresParser.PContext,0)


        def C(self):
            return self.getToken(compiladoresParser.C, 0)

        def param(self):
            return self.getTypedRuleContext(compiladoresParser.ParamContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_param

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParam" ):
                listener.enterParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParam" ):
                listener.exitParam(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParam" ):
                return visitor.visitParam(self)
            else:
                return visitor.visitChildren(self)




    def param(self):

        localctx = compiladoresParser.ParamContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_param)
        try:
            self.state = 313
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 307
                self.p()
                self.state = 308
                self.match(compiladoresParser.C)
                self.state = 309
                self.param()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 311
                self.p()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(compiladoresParser.TipoContext,0)


        def ID(self):
            return self.getToken(compiladoresParser.ID, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_p

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterP" ):
                listener.enterP(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitP" ):
                listener.exitP(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitP" ):
                return visitor.visitP(self)
            else:
                return visitor.visitChildren(self)




    def p(self):

        localctx = compiladoresParser.PContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 315
            self.tipo()
            self.state = 316
            self.match(compiladoresParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IreturnContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(compiladoresParser.RETURN, 0)

        def opal(self):
            return self.getTypedRuleContext(compiladoresParser.OpalContext,0)


        def PYC(self):
            return self.getToken(compiladoresParser.PYC, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_ireturn

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIreturn" ):
                listener.enterIreturn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIreturn" ):
                listener.exitIreturn(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIreturn" ):
                return visitor.visitIreturn(self)
            else:
                return visitor.visitChildren(self)




    def ireturn(self):

        localctx = compiladoresParser.IreturnContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_ireturn)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 318
            self.match(compiladoresParser.RETURN)
            self.state = 319
            self.opal()
            self.state = 320
            self.match(compiladoresParser.PYC)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IllamadaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(compiladoresParser.ID, 0)

        def PA(self):
            return self.getToken(compiladoresParser.PA, 0)

        def argumento(self):
            return self.getTypedRuleContext(compiladoresParser.ArgumentoContext,0)


        def PC(self):
            return self.getToken(compiladoresParser.PC, 0)

        def getRuleIndex(self):
            return compiladoresParser.RULE_illamada

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIllamada" ):
                listener.enterIllamada(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIllamada" ):
                listener.exitIllamada(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIllamada" ):
                return visitor.visitIllamada(self)
            else:
                return visitor.visitChildren(self)




    def illamada(self):

        localctx = compiladoresParser.IllamadaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_illamada)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 322
            self.match(compiladoresParser.ID)
            self.state = 323
            self.match(compiladoresParser.PA)
            self.state = 324
            self.argumento()
            self.state = 325
            self.match(compiladoresParser.PC)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(compiladoresParser.ID, 0)

        def C(self):
            return self.getToken(compiladoresParser.C, 0)

        def argumento(self):
            return self.getTypedRuleContext(compiladoresParser.ArgumentoContext,0)


        def getRuleIndex(self):
            return compiladoresParser.RULE_argumento

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgumento" ):
                listener.enterArgumento(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgumento" ):
                listener.exitArgumento(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgumento" ):
                return visitor.visitArgumento(self)
            else:
                return visitor.visitChildren(self)




    def argumento(self):

        localctx = compiladoresParser.ArgumentoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_argumento)
        try:
            self.state = 332
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 327
                self.match(compiladoresParser.ID)
                self.state = 328
                self.match(compiladoresParser.C)
                self.state = 329
                self.argumento()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 330
                self.match(compiladoresParser.ID)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





