import TipoDato
class ID:
    def __init__(self):   
        self.nombre : str
        self.tipoDato : TipoDato
        self.inicializado : bool
        self.usado : bool
            